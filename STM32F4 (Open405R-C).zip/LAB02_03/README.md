# Lab_SDcard_LCD
Release
v0.0.1: read 1 file and display on LCD